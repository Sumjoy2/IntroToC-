#pragma once

int Clamp(int Lowest, int Highest, int InNumber);
float Clamp(float Lowest, float Highest, float InNumber);